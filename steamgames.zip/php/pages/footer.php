<div class="page-modals">
   
    <div class="uk-flex-top" id="modal-help" data-uk-modal>
        <div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical"><button class="uk-modal-close-default" type="button" data-uk-close></button>
            <h2 class="uk-modal-title">Help</h2>

            <div class="uk-margin-small-left uk-margin-small-bottom uk-margin-medium-top">
                <h4>Popular Q&A</h4>
                <ul onclick="window.location.href ='help.php'">
                    <li><img src="assets/img/clipboard-text.svg" alt="icon"><span>How can i purchase game?</span></li>
                    <li><img src="assets/img/clipboard-text.svg" alt="icon"><span>Find TXT ID.</span></li>
                    <li><img src="assets/img/clipboard-text.svg" alt="icon"><span>When i get ID Password</span></li>
                </ul>
                <ul>
                    <li><a href="help.php">browse all articles</a></li>
                    <li><a href="contact.php">Need more Help?</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="uk-flex-top" id="search-mobile" data-uk-modal>
        <div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical" style="height: 100%; overflow:scroll; color:white;">
            <button class="uk-modal-close-default" type="button" data-uk-close></button>
            <div class="search">
                <div class="search__input"><i class="ico_search"></i><input type="search" name="search" class="search-input" autocomplete="off" placeholder="Search"></div>
                <div class="search__btn"></div>
            </div>
            <div class="autocomplete-suggestions"></div>
        </div>

    </div>
</div>

<script src="assets/js/libs.js"></script>
<script src="assets/js/main.js"></script>